import { Routes, Route } from "react-router-dom";
import './App.css';
import Dashboard from './pages/Dashboard/Dashboard';
import  Payments  from './pages/Payments/Payments';
import Navbar from './components/Navbar/Navbar'; 


function App() {
  return (
<div>
<Navbar />
<Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/history" element={<Payments />} />
      </Routes>
</div>
     
      
  
    
  );
}

export default App;