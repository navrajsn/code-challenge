import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import PaymentModal from './PaymentModal';

describe('PaymentModal Component', () => {
  const mockCloseModal = jest.fn();

  test('renders payment modal with account balance', () => {
    render(<PaymentModal accountBalance={100} closeModal={mockCloseModal} />);

    // Check if the modal renders with the correct account balance
    expect(screen.getByText('Make a Payment')).toBeInTheDocument();
    expect(screen.getByText('Account Balance: 100')).toBeInTheDocument();
  });

  test('allows user to input payment details', () => {
    render(<PaymentModal accountBalance={100} closeModal={mockCloseModal} />);

    // Input payment amount
    const paymentInput = screen.getByPlaceholderText('Enter payment amount');
    fireEvent.change(paymentInput, { target: { value: 50 } });
    expect(paymentInput).toHaveValue(50); 

    // Input credit card number
    const creditCardInput = screen.getByPlaceholderText('Enter credit card number');
    fireEvent.change(creditCardInput, { target: { value: '4111 1111 1111 1111' } });
    expect(creditCardInput).toHaveValue('4111 1111 1111 1111');

    // Input expiry date
    const expiryDateInput = screen.getByPlaceholderText('MM/YY');
    fireEvent.change(expiryDateInput, { target: { value: '12/25' } });
    expect(expiryDateInput).toHaveValue('12/25');

    // Input CVV
    const cvvInput = screen.getByPlaceholderText('Enter CVV');
    fireEvent.change(cvvInput, { target: { value: '123' } });
    expect(cvvInput).toHaveValue('123');
  });

  test('calls closeModal when "Close" button is clicked', () => {
    render(<PaymentModal accountBalance={100} closeModal={mockCloseModal} />);

    // Click the "Close" button
    const closeButton = screen.getByText('Close');
    fireEvent.click(closeButton);

    // Ensure closeModal is called
    expect(mockCloseModal).toHaveBeenCalledTimes(1);
  });
});