import React, { useState } from 'react';
import './PaymentModal.css';

interface PaymentModalProps {
  accountBalance: number | undefined;
  closeModal: () => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ accountBalance, closeModal }) => {
  const [creditCard, setCreditCard] = useState('');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [isPaymentSuccessful, setIsPaymentSuccessful] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};

    // Validate payment amount
    if (!paymentAmount || parseFloat(paymentAmount) <= 0) {
      newErrors.paymentAmount = 'Payment amount must be greater than 0';
    }

    // Validate credit card number
    const sanitizedCardNumber = creditCard.replace(/\s/g, '');
    if (!sanitizedCardNumber || sanitizedCardNumber.length < 16) {
      newErrors.creditCard = 'Credit card number must be 16 digits';
    }

    // Validate expiry date
    const [month, year] = expiryDate.split('/');
    if (!month || !year || parseInt(month) < 1 || parseInt(month) > 12 || year.length !== 2) {
      newErrors.expiryDate = 'Invalid expiry date (MM/YY)';
    }

    // Validate CVV
    if (!cvv || cvv.length !== 3) {
      newErrors.cvv = 'CVV must be 3 digits';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (validateForm()) {
      handlePayment();
    }
  };

  const handlePayment = async () => {
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      setIsPaymentSuccessful(true);
    } catch (error) {
      console.error('Payment failed:', error);
    }
  };

  const handleCreditCardChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const input = e.target.value.replace(/\D/g, ''); 
    const formatted = input
      .replace(/(\d{4})(?=\d)/g, '$1 ') 
      .trim(); 
    setCreditCard(formatted);
  };

  return (
    <div className="modal">
      <div className="modal-content">
        {isPaymentSuccessful ? (
          <div>
            <h2>Payment Successful</h2>
            <button onClick={closeModal}>Close</button>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <h2>Make a Payment</h2>
            <p>Account Balance: {accountBalance}</p>
            <label>
              How much would you like to pay?
              <input
                type="number"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(e.target.value)}
                placeholder="Enter payment amount"
              />
              {errors.paymentAmount && <p style={{ color: 'red' }}>{errors.paymentAmount}</p>}
            </label>
            <label>
              Credit Card Details:
              <input
                type="text"
                value={creditCard}
                onChange={handleCreditCardChange}
                placeholder="Enter credit card number"
              />
              {errors.creditCard && <p style={{ color: 'red' }}>{errors.creditCard}</p>}
            </label>
            <div className="expiry-cvv-container">
              <label>
                Expiry Date:
                <input
                  type="text"
                  value={expiryDate}
                  onChange={(e) => setExpiryDate(e.target.value)}
                  placeholder="MM/YY"
                />
                {errors.expiryDate && <p style={{ color: 'red' }}>{errors.expiryDate}</p>}
              </label>
              <label>
                CVV:
                <input
                  type="password"
                  value={cvv}
                  onChange={(e) => {
                    const input = e.target.value;
                    if (/^\d{0,3}$/.test(input)) {
                      setCvv(input);
                    }
                  }}
                  placeholder="Enter CVV"
                />
                {errors.cvv && <p style={{ color: 'red' }}>{errors.cvv}</p>}
              </label>
            </div>
            <button type="submit">Pay</button>
            <button type="button" onClick={closeModal}>
              Close
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default PaymentModal;