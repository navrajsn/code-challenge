import  { useState } from 'react';
import './EnergyTypeFilter.css'; 

interface EnergyTypeFilterProps {
  energyTypes: string[];
  selectedEnergyType: string;
  onSelect: (energyType: string) => void;
}

const EnergyTypeFilter: React.FC<EnergyTypeFilterProps> = ({
  energyTypes,
  selectedEnergyType,
  onSelect,
}) => {
  const [isListVisible, setIsListVisible] = useState(false); // State to toggle the list visibility

  const toggleListVisibility = () => {
    setIsListVisible((prev) => !prev);
  };

  return (
    <div className="filter-dropdown">
      <button onClick={toggleListVisibility} className="toggle-button">
       Energy Types 
      </button>
      {isListVisible && ( // Conditionally render the list
        <ul id="energyTypeFilter" className="energy-type-list">
          <li
            className={selectedEnergyType === '' ? 'selected' : ''}
            onClick={() => onSelect('')}
          >
            All
          </li>
          {energyTypes.map((type) => (
            <li
              key={type}
              className={selectedEnergyType === type ? 'selected' : ''}
              onClick={() => onSelect(type)}
            >
              {type}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default EnergyTypeFilter;