import { render, screen, fireEvent } from '@testing-library/react';
import EnergyTypeFilter from './EnergyTypeFilter';

describe('EnergyTypeFilter Component', () => {
  const mockOnSelect = jest.fn();
  const energyTypes = ['Solar', 'Wind', 'Hydro'];

  beforeEach(() => {
    jest.clearAllMocks(); // Clear mock calls before each test
  });

  test('renders the toggle button', () => {
    render(
      <EnergyTypeFilter
        energyTypes={energyTypes}
        selectedEnergyType=""
        onSelect={mockOnSelect}
      />
    );

    // Check if the toggle button is rendered
    const toggleButton = screen.getByText('Energy Types');
    expect(toggleButton).toBeInTheDocument();
  });

  test('toggles the visibility of the energy type list', () => {
    render(
      <EnergyTypeFilter
        energyTypes={energyTypes}
        selectedEnergyType=""
        onSelect={mockOnSelect}
      />
    );

    // Initially, the list should not be visible
    expect(screen.queryByRole('list')).not.toBeInTheDocument();

    // Click the toggle button to show the list
    const toggleButton = screen.getByText('Energy Types');
    fireEvent.click(toggleButton);
    expect(screen.getByRole('list')).toBeInTheDocument();

    // Click the toggle button again to hide the list
    fireEvent.click(toggleButton);
    expect(screen.queryByRole('list')).not.toBeInTheDocument();
  });

  test('renders all energy types in the list', () => {
    render(
      <EnergyTypeFilter
        energyTypes={energyTypes}
        selectedEnergyType=""
        onSelect={mockOnSelect}
      />
    );

    // Show the list
    const toggleButton = screen.getByText('Energy Types');
    fireEvent.click(toggleButton);

    // Check if all energy types are rendered
    energyTypes.forEach((type) => {
      expect(screen.getByText(type)).toBeInTheDocument();
    });

    // Check if the "All" option is rendered
    expect(screen.getByText('All')).toBeInTheDocument();
  });

  test('calls onSelect when an energy type is clicked', () => {
    render(
      <EnergyTypeFilter
        energyTypes={energyTypes}
        selectedEnergyType=""
        onSelect={mockOnSelect}
      />
    );

    // Show the list
    const toggleButton = screen.getByText('Energy Types');
    fireEvent.click(toggleButton);

    // Click on an energy type
    const solarOption = screen.getByText('Solar');
    fireEvent.click(solarOption);

    // Ensure onSelect is called with the correct value
    expect(mockOnSelect).toHaveBeenCalledTimes(1);
    expect(mockOnSelect).toHaveBeenCalledWith('Solar');
  });

  test('highlights the selected energy type', () => {
    render(
      <EnergyTypeFilter
        energyTypes={energyTypes}
        selectedEnergyType="Wind"
        onSelect={mockOnSelect}
      />
    );

    // Show the list
    const toggleButton = screen.getByText('Energy Types');
    fireEvent.click(toggleButton);

    // Check if the selected energy type is highlighted
    const windOption = screen.getByText('Wind');
    expect(windOption).toHaveClass('selected');
  });
});