import { Link } from 'react-router-dom';
import './Navbar.css';

const Navbar: React.FC = () => {
  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-link">
          Dashboard
        </Link>
        <Link to="/history" className="navbar-link">
          Payment History
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;