import React, { useState } from 'react';
import { type Account } from '../../types';
import './AccountCard.css';
import PaymentModal from '../PaymentModal/PaymentModal';

interface AccountCardProps {
  account: Account;
}

const AccountCard: React.FC<AccountCardProps> = ({ account }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const getBalanceColor = (dueAmount: number | undefined) => {
    if (dueAmount === undefined) return 'black';
    if (dueAmount < 0) return 'red';
    if (dueAmount === 0) return 'gray';
    return 'green';
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <div className="account-card">
      <div className="icon"></div>
      <div className="account-details">
        <h3>{account.type}</h3>
        <p>{account.id}</p>
        <p>{account.address}</p>
        <div className="account-balance">
          <p>Account Balance</p>
          <p style={{ color: getBalanceColor(account.dueAmount) }}>{account.dueAmount}</p>
        </div>
        <button onClick={() => setIsModalOpen(true)}
         disabled={(account.dueAmount ?? 0) <= 0} // Disable button if dueAmount is <= 0
         className={(account.dueAmount ?? 0) <= 0 ? 'disabled-button' : ''}
          >Make a Payment</button>
      </div>
      {isModalOpen && (
        <PaymentModal
          accountBalance={account.dueAmount}
          closeModal={closeModal}
        />
      )}
    </div>
  );
};

export default AccountCard;