import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import AccountCard from './AccountCard';
import { type Account } from '../../types';

jest.mock('../PaymentModal/PaymentModal', () => {
  return ({ accountBalance, closeModal }: { accountBalance: number; closeModal: () => void }) => (
    <div data-testid="payment-modal">
      <p>Payment Modal</p>
      <p>Account Balance: {accountBalance}</p>
      <button onClick={closeModal}>Close</button>
    </div>
  );
});

const mockAccount: Account = {
  id: '1',
  type: 'Electricity',
  address: '123 Main St',
  dueAmount: 100,
};

describe('AccountCard Component', () => {
  test('renders account details correctly', () => {
    render(<AccountCard account={mockAccount} />);

    // Check if account type, id, and address are rendered
    expect(screen.getByText('Electricity')).toBeInTheDocument();
    expect(screen.getByText('1')).toBeInTheDocument();
    expect(screen.getByText('123 Main St')).toBeInTheDocument();

    // Check if account balance is rendered
    expect(screen.getByText('Account Balance')).toBeInTheDocument();
    expect(screen.getByText('100')).toBeInTheDocument();
  });

  test('opens and closes the payment modal', () => {
    render(<AccountCard account={mockAccount} />);

    // Check that the modal is not visible initially
    expect(screen.queryByTestId('payment-modal')).not.toBeInTheDocument();

    // Click the "Make a Payment" button to open the modal
    fireEvent.click(screen.getByText('Make a Payment'));
    expect(screen.getByTestId('payment-modal')).toBeInTheDocument();
    expect(screen.getByText('Account Balance: 100')).toBeInTheDocument();

    // Click the "Close" button to close the modal
    fireEvent.click(screen.getByText('Close'));
    expect(screen.queryByTestId('payment-modal')).not.toBeInTheDocument();
  });

  test('renders balance color correctly', () => {
    const { rerender } = render(<AccountCard account={{ ...mockAccount, dueAmount: -50 }} />);
    expect(screen.getByText('-50')).toHaveStyle('color: red');

    rerender(<AccountCard account={{ ...mockAccount, dueAmount: 0 }} />);
    expect(screen.getByText('0')).toHaveStyle('color: gray');

    rerender(<AccountCard account={{ ...mockAccount, dueAmount: 200 }} />);
    expect(screen.getByText('200')).toHaveStyle('color: green');
  });
});