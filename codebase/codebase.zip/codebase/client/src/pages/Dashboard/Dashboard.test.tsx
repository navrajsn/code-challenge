import { render, screen, waitFor } from '@testing-library/react';
import Dashboard from './Dashboard';
import { MOCK_ENERGY_ACCOUNTS_API } from '../../mocks/energyAccountsAPIMock';
import { MOCK_DUE_CHARGES_API } from '../../mocks/dueChargesAPI';
import '@testing-library/jest-dom';

// Mock the API calls
jest.mock('../../mocks/energyAccountsAPIMock', () => ({
  MOCK_ENERGY_ACCOUNTS_API: jest.fn(),
}));

jest.mock('../../mocks/dueChargesAPI', () => ({
  MOCK_DUE_CHARGES_API: jest.fn(),
}));

describe('Dashboard Component', () => {
  const mockAccounts = [
    { id: '1', type: 'Solar', address: '123 Solar St', dueAmount: 50 },
    { id: '2', type: 'Wind', address: '456 Sad Ave', dueAmount: 0 },
    { id: '3', type: 'Hydro', address: '789 Smile Blvd', dueAmount: 100 },
  ];

  const mockDueCharges = [
    { accountId: '1', amount: 50 },
    { accountId: '3', amount: 100 },
  ];

  beforeEach(() => {
    jest.clearAllMocks();
    (MOCK_ENERGY_ACCOUNTS_API as jest.Mock).mockResolvedValue(mockAccounts);
    (MOCK_DUE_CHARGES_API as jest.Mock).mockResolvedValue(mockDueCharges);
  });

  test('renders loading state initially', async() => {
    render(<Dashboard />);
    await waitFor(() => {
      expect(screen.getByText('Loading...')).toBeInTheDocument();

    })
  });

  test('renders accounts after loading', async () => {
    render(<Dashboard />);

    // Wait for the accounts to load
    await waitFor(() => {
      expect(screen.getByText('123 Solar St')).toBeInTheDocument();
      expect(screen.getByText('456 Sad Ave')).toBeInTheDocument();
      expect(screen.getByText('789 Smile Blvd')).toBeInTheDocument();
    });
  });

  
});