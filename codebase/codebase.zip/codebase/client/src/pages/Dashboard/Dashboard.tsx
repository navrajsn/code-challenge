import { useEffect, useState } from 'react';
import { MOCK_ENERGY_ACCOUNTS_API } from '../../mocks/energyAccountsAPIMock';
import { MOCK_DUE_CHARGES_API } from '../../mocks/dueChargesAPI';
import { type Account } from '../../types';
import { type DueCharges } from '../../types';
import AccountCard from '../../components/AccountCard/AccountCard';
import EnergyTypeFilter from '../../components/EnergyTypeFilter/EnergyTypeFilter';
import SearchBar from '../../components/SearchBar/SearchBar';
import './Dashboard.css';

const Dashboard: React.FC = () => {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [dueCharges, setDueCharges] = useState<DueCharges[]>([]);
  const [filteredAccounts, setFilteredAccounts] = useState<Account[]>([]);
  const [selectedEnergyType, setSelectedEnergyType] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState<string>('');

  useEffect(() => {
    const fetchAccounts = async () => {
      try {
    
          const [accountsData, dueChargesData] = await Promise.all([
            MOCK_ENERGY_ACCOUNTS_API(),
            MOCK_DUE_CHARGES_API(),
          ]);
          setAccounts(accountsData);
          setDueCharges(dueChargesData);
          setFilteredAccounts(accountsData);
       
     
          // Initialize filtered accounts
      } catch (error) {
        console.error('Error fetching accounts:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchAccounts();
  }, []);

  const getDueAmountsByAccount = (accounts: Account[], dueCharges: DueCharges[]) => {
    return accounts.map((account) => {
      const dueCharge = dueCharges.find((charge) => charge.accountId === account.id);
      return {
        ...account,
        dueAmount: dueCharge ? dueCharge.amount : 0, // Add `dueAmount` to the account object
      };
    });
  };

  const applyFilters = (energyType: string, searchTerm: string) => {
    setSelectedEnergyType(energyType);
    setSearchTerm(searchTerm);

    let filtered = accounts;

    if (energyType) {
      filtered = filtered.filter((account) => account.type === energyType);
    }

    if (searchTerm) {
      filtered = filtered.filter((account) =>
        account.address.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredAccounts(filtered);
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  const energyTypes = [...new Set(accounts.map((account) => account.type))];

  return (
    <div className="dashboard-container">
      <h1>Dashboard</h1>
      <p>Welcome to the energy app dashboard!</p>

      <div className="filters-container">
        <div className="filter-item">
          <SearchBar
        value={searchTerm}
        onChange={(value: string) => applyFilters(selectedEnergyType, value)}
        placeholder="Search by Address"
          />
        </div>

        <EnergyTypeFilter
          energyTypes={energyTypes}
          selectedEnergyType={selectedEnergyType}
          onSelect={(type: string) => applyFilters(type, searchTerm)}
        />
      </div>

      {getDueAmountsByAccount(filteredAccounts, dueCharges).map((account) => (
        <AccountCard key={account.id} account={account} />
      ))}
    </div>
  );
};

export default Dashboard;


