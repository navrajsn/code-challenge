import  { useState, useEffect } from 'react';
import './Payments.css'; // Import the CSS file
import { fetchMockPaymentHistory } from '../../mocks/mockPaymentsAPI'; // Import the mock API

interface Payment {
  id: string;
  accountId: string;
  amount: number;
  date: string;
  status: string;
}

const Payments: React.FC = () => {
  const [paymentHistory, setPaymentHistory] = useState<Payment[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchPayments = async () => {
      try {
        const data = await fetchMockPaymentHistory(); 
        setPaymentHistory(data);
      } catch (error) {
        console.log('Error fetching payment history:', error);
      } finally {
        setLoading(false); // Set loading to false after fetching
      }
    };

    fetchPayments();
  }, []);

  if (loading) {
    return <p>Loading payment history...</p>; // Show a loading message while fetching
  }

  return (
    <div className="payments-container">
      <h1>Payment History</h1>
      <table className="payments-table">
        <thead>
          <tr>
            <th>Payment ID</th>
            <th>Account ID</th>
            <th>Amount</th>
            <th>Date</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {paymentHistory.map((payment) => (
            <tr key={payment.id}>
              <td>{payment.id}</td>
              <td>{payment.accountId}</td>
              <td>${payment.amount}</td>
              <td>{payment.date}</td>
              <td>{payment.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Payments;