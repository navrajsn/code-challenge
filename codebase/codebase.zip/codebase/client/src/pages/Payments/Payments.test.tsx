import { render, screen, waitFor, act } from '@testing-library/react';
import Payments from './Payments';
import { fetchMockPaymentHistory } from '../../mocks/mockPaymentsAPI';
import '@testing-library/jest-dom';

// Mock the API call
jest.mock('../../mocks/mockPaymentsAPI', () => ({
  fetchMockPaymentHistory: jest.fn(),
}));

describe('Payments Component', () => {
  const mockPaymentHistory = [
    { id: '1', accountId: '12345', amount: 50, date: '2025-05-30', status: 'Successful' },
    { id: '2', accountId: '67890', amount: 75, date: '2025-05-29', status: 'Successful' },
    { id: '3', accountId: '54321', amount: 100, date: '2025-05-28', status: 'Failed' },
  ];

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('handles API errors gracefully', async () => {
    // Mock the API to reject with an error
    (fetchMockPaymentHistory as jest.Mock).mockRejectedValue(new Error('Failed to fetch'));

    await act(async () => {
      render(<Payments />);
    });

    // Wait for the loading state to disappear
    await waitFor(() => {
      expect(screen.queryByText('Loading payment history...')).not.toBeInTheDocument();
    });

    // Check if the error is handled gracefully
    expect(screen.getByText('Payment History')).toBeInTheDocument();
    expect(screen.queryByText('12345')).not.toBeInTheDocument();
  });

  test('renders payment history after loading', async () => {
    // Mock the API to resolve with mock data
    (fetchMockPaymentHistory as jest.Mock).mockResolvedValue(mockPaymentHistory);

    await act(async () => {
      render(<Payments />);
    });

    // Wait for the data to load
    await waitFor(() => {
      expect(screen.getByText('Payment History')).toBeInTheDocument();
    });

    // Check if the payment history is rendered
    expect(screen.getByText('12345')).toBeInTheDocument();
    expect(screen.getByText('$50')).toBeInTheDocument();
    expect(screen.getByText('2025-05-30')).toBeInTheDocument();
  });
});