interface Payment {
  id: string;
  accountId: string;
  amount: number;
  date: string;
  status: string;
}

export const mockPaymentHistory: Payment[] = [
  { id: '1', accountId: '12345', amount: 50, date: '2025-05-30', status: 'Successful' },
  { id: '2', accountId: '67890', amount: 75, date: '2025-05-29', status: 'Successful' },
  { id: '3', accountId: '54321', amount: 100, date: '2025-05-28', status: 'Failed' },
];

// Simulate fetching payment history from an API
export const fetchMockPaymentHistory = (): Promise<Payment[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockPaymentHistory);
    }, 1000); // Simulate a 1-second delay
  });
};