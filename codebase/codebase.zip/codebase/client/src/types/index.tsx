export interface Account {
    id: string;
    type: string;
    address: string;
    volume?: number;
    meterNumber?: string;
    dueAmount?: number;
  }
 

  export type DueCharges = {
    id: string;
    accountId: string; 
    date: string;
    amount: number
}